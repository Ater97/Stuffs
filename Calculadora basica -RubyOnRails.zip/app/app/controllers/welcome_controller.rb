class WelcomeController < ApplicationController
  def index
  	@nombre_desarrolladores = 'Macario & Chang'
  end
end
