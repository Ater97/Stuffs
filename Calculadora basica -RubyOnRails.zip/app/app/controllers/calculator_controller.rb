#Clase que se encarga de operar segun el operador y los números ingresados...
class Operations
  
#Método que realiza la operación multiplicacion...
 def multiplication(number1, number2)
   return number1 * number2
 end

#Método que realiza la operación de división...
 def division(number1, number2)
   return number1 / number2
 end

#Método que realiza la suma de dos números...
 
 def addition(number1, number2)
   return number1 + number2
 end
 
 #Método que realiza la resta de dos números...
 def subtraction(number1, number2)
   return number1 - number2
 end
 
 #Método que realiza la operación de potencia...
 def elevation(number, exponent)

 	if(exponent != 0)
 		answer = number
    	for i in 1..(exponent - 1)
    		answer = answer * number
  		end

  		return answer
 	end

    return 1
 end

end

#Controlador 
class CalculatorController < ApplicationController
  
   def is_number caracter
  	 true if Float(caracter)	rescue false
   end

   def jerarquia operador

  	respuesta = case operador
  	when "+", "-" then 1
  	when "*", "/" then 2
  	when "^" then 3
  	else "Error operador no válido."
  	end

  	return respuesta

  end

  def comparar_operadores o_ingresa, o_pila

  	if(jerarquia(o_ingresa).to_i > jerarquia(o_pila).to_i)
  		return 1
  	end

  	if(jerarquia(o_ingresa).to_i < jerarquia(o_pila).to_i)
  		return -1
  	end

  	if(jerarquia(o_ingresa).to_i == jerarquia(o_pila).to_i)
  		return 0
  	end
  end

  def Operar operador, numero1, numero2

  	resultado = case operador
  	when "+" then Operations.new.addition(numero1.to_f, numero2.to_f)
  	when "-" then Operations.new.subtraction(numero2.to_f, numero1.to_f) 
  	when "*" then Operations.new.multiplication(numero1.to_f, numero2.to_f)
  	when "/" then Operations.new.division(numero2.to_f, numero1.to_f)
  	when "^" then Operations.new.elevation(numero2.to_i, numero1.to_i)
  	end

  	return resultado
  end

  def form
  		@operacion = params[:operacion_ingresada]
  		@operacion = @operacion.to_s
  		@arreglo_operacion = []
  		@arreglo_operacion =  @operacion.split(" ")

  		#Stacks
  		@stack_Numeros = []
  		@stack_Operadores = []

  	
  		@arreglo_operacion.each do |elemento|

  			if(elemento != " ")

  				if(is_number(elemento))
  					@stack_Numeros.push(elemento)
  				else
  					while(comparar_operadores(elemento, @stack_Operadores.last) == -1)
  						@agregar = Operar(@stack_Operadores.pop, @stack_Numeros.pop, @stack_Numeros.pop)
  						@stack_Numeros.push(@agregar)
  					end
  					@stack_Operadores.push(elemento)
  				end
  			end
  		end

  		while(@stack_Operadores.empty? == false)
  			@agregar = Operar(@stack_Operadores.pop, @stack_Numeros.pop, @stack_Numeros.pop)
  			@stack_Numeros.push(@agregar)
  		end

  		@result = @stack_Numeros.pop

  end

end


