class Operations
  
 def self.multiplication(number1, number2)
   return number1 * number2
 end

 def self.division(number1, number2)
   return number1 / number2
 end
 
 def self.addition(number1, number2)
   return number1 + number2
 end
 
 def self.subtraction(number1, number2)
   return number1 - number2
 end
 
 def self.elevation(number, exponent)
   answer = number
   for i in 1..exponent
    answer = answer * number
  end
    return answer 
 end

end
