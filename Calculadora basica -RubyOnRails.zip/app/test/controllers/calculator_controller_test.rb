require 'test_helper'

class CalculatorControllerTest < ActionDispatch::IntegrationTest
  test "should get form" do
    get calculator_form_url
    assert_response :success
  end

end
